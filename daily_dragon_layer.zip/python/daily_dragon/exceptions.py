class WordAlreadyExistsError(Exception):
    """Exception raised when a word already exists in the database."""
    pass
